﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5g
{
    public partial class Form1 : Form
    {
        private Point mouseLocation;
       

        public Form1()
        {
            InitializeComponent();
            closeTimer = new Timer();
            closeTimer.Interval = 10000; // Set interval to 10 seconds (10000 ms)
            closeTimer.Tick += CloseTimer_Tick; // Event handler when timer ticks
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);

        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (siticoneTextBox1.Text == "Kurmis")
            {
                Form2 f1 = new Form2();
                f1.Show(); this.Hide();
            }
            if (siticoneTextBox1.Text == "kurmis")
            {
                Form2 f1 = new Form2();
                f1.Show(); this.Hide();
            }
            
        }

        private void siticoneTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/niks_ar_g/profilecard/?igsh=azI5cW03MmNudXdy");
        }

        private void siticoneTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            string password1 = "kurmis";
            string password2 = "Kurmis";

            // Check if the entered text matches either password
            if (siticoneTextBox1.Text == password1 || siticoneTextBox1.Text == password2)
            {
                // Check if the Enter key is pressed
                if (e.KeyCode == Keys.Enter)
                {
                    Form2 f1 = new Form2();
                    f1.Show();
                    this.Hide();

                    closeTimer.Start();

                }
            }

        }

       

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            // Stop the timer
            closeTimer.Stop();

            // Close the application
            Application.Exit(); // This closes the application
        }

        private void CloseTimer_Tick(object sender, EventArgs e)
        {
            closeTimer.Stop(); // Stop the timer
            Application.Exit(); // Close the application
        }
    }
}
    

